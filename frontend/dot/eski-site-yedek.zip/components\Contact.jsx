import { useState } from 'react'
import { useReveal } from '../hooks/useAnimations'

export default function Contact() {
  const ref = useReveal()
  const [form, setForm] = useState({ name: '', phone: '', email: '', service: '', message: '' })
  const [sent, setSent] = useState(false)

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const submit = (e) => {
    e.preventDefault()
    console.log('Form:', form)
    setSent(true)
    setTimeout(() => setSent(false), 3000)
    setForm({ name: '', phone: '', email: '', service: '', message: '' })
  }

  const inputClass = 'w-full px-0 py-3 bg-transparent border-b border-gray-200 text-charcoal placeholder-gray-400 focus:outline-none focus:border-pink-500 transition-colors duration-300 text-sm'

  return (
    <section id="iletisim" className="py-20 lg:py-32 bg-pink-50">
      <div ref={ref} className="fade-up max-w-7xl mx-auto px-6 lg:px-10">
        {/* Başlık */}
        <div className="text-center mb-16">
          <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-4">
            İletişim
          </p>
          <h2 className="font-heading text-4xl lg:text-5xl font-bold text-charcoal">
            Randevu Alın
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-16">
          {/* Sol — İletişim Bilgileri */}
          <div className="lg:col-span-2 space-y-8">
            {[
              {
                label: 'Adres',
                value: 'Örnek Mah. Güzellik Cad.\nNo: 42, Kat: 2, İstanbul',
                icon: 'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z M15 11a3 3 0 11-6 0 3 3 0 016 0z',
              },
              {
                label: 'Telefon',
                value: '+90 (212) 555 00 00',
                icon: 'M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z',
              },
              {
                label: 'Çalışma Saatleri',
                value: 'Pzt - Cmt: 09:00 - 21:00\nPazar: 10:00 - 18:00',
                icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
              },
              {
                label: 'E-posta',
                value: 'info@estepink.com',
                icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z',
              },
            ].map((item, i) => (
              <div key={i} className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={item.icon} />
                  </svg>
                </div>
                <div>
                  <p className="text-charcoal font-semibold text-sm mb-1">{item.label}</p>
                  <p className="text-text-secondary text-sm whitespace-pre-line leading-relaxed">{item.value}</p>
                </div>
              </div>
            ))}

            {/* Sosyal Medya */}
            <div className="pt-4">
              <p className="text-charcoal font-semibold text-sm mb-4">Bizi Takip Edin</p>
              <div className="flex gap-3">
                {/* Instagram */}
                <a href="#" className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="Instagram">
                  <svg className="w-[18px] h-[18px]" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                  </svg>
                </a>
                {/* Facebook */}
                <a href="#" className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="Facebook">
                  <svg className="w-[18px] h-[18px]" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>
                {/* TikTok */}
                <a href="#" className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="TikTok">
                  <svg className="w-[18px] h-[18px]" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Sağ — Form */}
          <div className="lg:col-span-3">
            <form onSubmit={submit} className="bg-white rounded-2xl p-8 lg:p-10 shadow-sm">
              <div className="grid sm:grid-cols-2 gap-x-8 gap-y-6">
                <div>
                  <label className="block text-charcoal text-xs font-semibold tracking-wide uppercase mb-1">Ad Soyad *</label>
                  <input type="text" name="name" value={form.name} onChange={handle} required className={inputClass} placeholder="Adınız Soyadınız" />
                </div>
                <div>
                  <label className="block text-charcoal text-xs font-semibold tracking-wide uppercase mb-1">Telefon *</label>
                  <input type="tel" name="phone" value={form.phone} onChange={handle} required className={inputClass} placeholder="05XX XXX XX XX" />
                </div>
                <div>
                  <label className="block text-charcoal text-xs font-semibold tracking-wide uppercase mb-1">E-posta</label>
                  <input type="email" name="email" value={form.email} onChange={handle} className={inputClass} placeholder="ornek@mail.com" />
                </div>
                <div>
                  <label className="block text-charcoal text-xs font-semibold tracking-wide uppercase mb-1">Hizmet</label>
                  <select name="service" value={form.service} onChange={handle} className={`${inputClass} cursor-pointer appearance-none`}>
                    <option value="">Seçiniz</option>
                    <option value="lazer">Lazer Epilasyon</option>
                    <option value="cilt">Cilt Bakımı</option>
                    <option value="medikal">Medikal Estetik</option>
                    <option value="hydra">Hydrafacial</option>
                    <option value="incelme">Bölgesel İncelme</option>
                    <option value="kirpik">İpek Kirpik</option>
                    <option value="diger">Diğer</option>
                  </select>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-charcoal text-xs font-semibold tracking-wide uppercase mb-1">Mesajınız</label>
                <textarea name="message" value={form.message} onChange={handle} rows={3} className={`${inputClass} resize-none`} placeholder="Mesajınızı yazın..." />
              </div>

              <button
                type="submit"
                className="mt-8 w-full py-4 bg-pink-500 text-white font-semibold tracking-wider uppercase rounded-full hover:bg-pink-600 transition-colors duration-300"
              >
                {sent ? '✓ Mesajınız Alındı' : 'Gönder'}
              </button>
            </form>
          </div>
        </div>

        {/* Harita */}
        <div className="mt-16 rounded-2xl overflow-hidden">
          <iframe
            title="EstePink Konum"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3010.2714735103394!2d28.97705931541773!3d41.00824797930016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab9e7a7777c43%3A0x4c76cf3dcc8b330b!2sS%C3%BCleymaniye%2C%20Fatih%2F%C4%B0stanbul!5e0!3m2!1str!2str!4v1694000000000!5m2!1str!2str"
            className="w-full h-[350px]"
            loading="lazy"
            allowFullScreen
          />
        </div>
      </div>
    </section>
  )
}
