import { useReveal } from '../hooks/useAnimations'

const services = [
  {
    title: 'Lazer Epilasyon',
    desc: 'FDA onaylı cihazlarla acısız ve kalıcı sonuçlar.',
    icon: 'M13 10V3L4 14h7v7l9-11h-7z',
  },
  {
    title: 'Cilt Bakımı',
    desc: 'Hydrafacial, peeling ve kişiye özel cilt bakım protokolleri.',
    icon: 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01',
  },
  {
    title: 'Medikal Estetik',
    desc: 'Botox, dolgu ve mezoterapi ile doğal gençlik.',
    icon: 'M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z',
  },
  {
    title: 'Hydrafacial',
    desc: 'Derin temizlik ve nemlendirme ile ışıltılı cilt.',
    icon: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z',
  },
  {
    title: 'Bölgesel İncelme',
    desc: 'Kavitasyon ve RF ile hedeflenen bölgelerde incelme.',
    icon: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
  },
  {
    title: 'İpek Kirpik',
    desc: 'Doğal ve etkileyici bakışlar için profesyonel uygulama.',
    icon: 'M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z',
  },
]

export default function Services() {
  const ref = useReveal()

  return (
    <section id="hizmetler" className="py-20 lg:py-32 bg-pink-50">
      <div ref={ref} className="fade-up max-w-7xl mx-auto px-6 lg:px-10">
        {/* Başlık */}
        <div className="text-center mb-16">
          <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-4">
            Hizmetlerimiz
          </p>
          <h2 className="font-heading text-4xl lg:text-5xl font-bold text-charcoal">
            Neler Yapıyoruz
          </h2>
        </div>

        {/* Hizmet Grid — ikon tabanlı kartlar */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((service, i) => (
            <div
              key={i}
              className="group bg-white rounded-2xl p-7 hover:shadow-xl hover:shadow-pink-100/80 transition-all duration-500 hover:-translate-y-1"
            >
              {/* İkon */}
              <div className="w-14 h-14 rounded-2xl bg-pink-50 flex items-center justify-center mb-5 group-hover:bg-pink-500 transition-colors duration-500">
                <svg className="w-6 h-6 text-pink-500 group-hover:text-white transition-colors duration-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={service.icon} />
                </svg>
              </div>

              {/* Metin */}
              <h3 className="font-heading text-xl font-bold text-charcoal mb-2 group-hover:text-pink-600 transition-colors duration-300">
                {service.title}
              </h3>
              <p className="text-text-secondary text-sm leading-relaxed">
                {service.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
