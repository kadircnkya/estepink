import { useState, useEffect, useRef } from 'react'

export default function Hero() {
  const [loaded, setLoaded] = useState(false)
  const imgRef = useRef(null)

  useEffect(() => {
    // Görsel zaten cache'deyse veya yüklendiyse hemen göster
    if (imgRef.current?.complete) {
      setLoaded(true)
    }
  }, [])

  return (
    <section
      id="anasayfa"
      className="relative w-full h-svh min-h-[600px] overflow-hidden bg-charcoal"
    >
      {/* Background image */}
      <picture>
        <source srcSet="/images/heroupdate-bg.webp" type="image/webp" />
        <img
          ref={imgRef}
          src="/images/heroupdate-bg.jpg"
          alt="EstePink Güzellik Merkezi — Salon"
          className={`absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-700 ${
            loaded ? 'opacity-100' : 'opacity-0'
          }`}
          loading="eager"
          fetchPriority="high"
          decoding="async"
          onLoad={() => setLoaded(true)}
        />
      </picture>

      {/* Gradient overlay — üst açık, alt koyu */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background: `linear-gradient(180deg,
            rgba(28,28,30,0.15) 0%,
            rgba(28,28,30,0.05) 25%,
            rgba(28,28,30,0.10) 45%,
            rgba(28,28,30,0.50) 65%,
            rgba(28,28,30,0.85) 82%,
            rgba(28,28,30,0.95) 100%
          )`,
        }}
      />

      {/* Content — altta konumlanmış */}
      <div className="relative z-20 flex flex-col items-center justify-end h-full text-center px-6 pb-24 sm:pb-28">
        <p className={`text-white/60 text-[11px] font-body font-medium tracking-[0.3em] uppercase mb-5 transition-all duration-1000 delay-200 ${
          loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          Estetik &amp; Güzellik Merkezi
        </p>

        <h1 className={`font-heading text-white font-bold leading-tight mb-4 transition-all duration-1000 delay-300 ${
          loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
          style={{ fontSize: 'clamp(2.2rem, 6vw, 5rem)' }}
        >
          Güzelliğinize<br />
          <span className="text-pink-400 italic">Dokunuyoruz</span>
        </h1>

        <p className={`text-white/70 text-base sm:text-lg max-w-xl leading-relaxed mb-8 font-body transition-all duration-1000 delay-400 ${
          loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          Uzman kadromuz ve son teknoloji cihazlarımızla,{' '}
          doğal güzelliğinizi ortaya çıkarıyoruz.
        </p>

        <div className={`flex flex-wrap gap-4 transition-all duration-1000 delay-500 ${
          loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          <a
            href="#iletisim"
            onClick={(e) => { e.preventDefault(); document.querySelector('#iletisim')?.scrollIntoView({ behavior: 'smooth' }) }}
            className="px-8 py-3.5 bg-pink-500 text-white text-sm font-semibold tracking-wider uppercase rounded-full hover:bg-pink-600 transition-colors duration-300"
          >
            Randevu Al
          </a>
          <a
            href="#hizmetler"
            onClick={(e) => { e.preventDefault(); document.querySelector('#hizmetler')?.scrollIntoView({ behavior: 'smooth' }) }}
            className="px-8 py-3.5 border border-white/30 text-white text-sm font-semibold tracking-wider uppercase rounded-full hover:bg-white/10 transition-colors duration-300"
          >
            Keşfet
          </a>
        </div>
      </div>

      {/* Bottom gradient fade → VideoShowcase ile yumuşak geçiş */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-charcoal to-transparent z-10 pointer-events-none" />

      {/* Scroll indicator */}
      <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 z-20 transition-all duration-1000 delay-700 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
        <div className="w-[1px] h-12 bg-gradient-to-b from-white/50 to-transparent mx-auto animate-pulse" />
      </div>
    </section>
  )
}
