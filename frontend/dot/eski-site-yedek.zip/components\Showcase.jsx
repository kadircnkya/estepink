import { useState, useEffect, useRef, useCallback } from 'react'
import { useReveal } from '../hooks/useAnimations'

const slides = [
  {
    src: '/images/showcase-lounge.webp',
    alt: 'EstePink Bekleme Salonu',
    title: 'Lüks Bekleme Alanı',
    subtitle: 'Randevunuz öncesi rahat bir ortamda keyifli anlar',
  },
  {
    src: '/images/showcase-laser-room.webp',
    alt: 'EstePink Lazer Odası',
    title: 'Profesyonel Uygulama',
    subtitle: 'Çift yataklı lazer odamızda en son teknoloji cihazlar',
  },
  {
    src: '/images/showcase-corridor.webp',
    alt: 'EstePink Koridor',
    title: 'Zarif Mekan Tasarımı',
    subtitle: 'Her detayıyla özenle tasarlanmış iç mekan',
  },
  {
    src: '/images/showcase-device.webp',
    alt: 'EstePink Cilt Bakım Cihazı',
    title: 'Son Teknoloji Cihazlar',
    subtitle: 'FDA onaylı profesyonel cilt bakım ve lazer cihazları',
  },
  {
    src: '/images/showcase-havlu.webp',
    alt: 'EstePink Havlu',
    title: 'Kişiye Özel Konfor',
    subtitle: 'Her misafirimiz için özenle hazırlanan kişisel malzemeler',
  },
]

const INTERVAL = 5000

export default function Showcase() {
  const sectionRef = useReveal()
  const [current, setCurrent] = useState(0)
  const [paused, setPaused] = useState(false)
  const [progressKey, setProgressKey] = useState(0)
  const touchStart = useRef(null)
  const intervalRef = useRef(null)

  const goTo = useCallback((index) => {
    setCurrent(index)
    setProgressKey((k) => k + 1)
  }, [])

  const next = useCallback(() => {
    goTo((current + 1) % slides.length)
  }, [current, goTo])

  const prev = useCallback(() => {
    goTo((current - 1 + slides.length) % slides.length)
  }, [current, goTo])

  // Auto-play
  useEffect(() => {
    if (paused) return
    intervalRef.current = setInterval(next, INTERVAL)
    return () => clearInterval(intervalRef.current)
  }, [next, paused])

  // Touch / Swipe
  const onTouchStart = (e) => {
    touchStart.current = e.touches[0].clientX
  }

  const onTouchEnd = (e) => {
    if (touchStart.current === null) return
    const diff = touchStart.current - e.changedTouches[0].clientX
    if (Math.abs(diff) > 50) {
      diff > 0 ? next() : prev()
    }
    touchStart.current = null
  }

  // Keyboard
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'ArrowRight') next()
      if (e.key === 'ArrowLeft') prev()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [next, prev])

  return (
    <section className="relative py-20 lg:py-32 bg-white overflow-hidden">
      {/* Top decorative gradient */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-pink-50/80 to-transparent pointer-events-none" />

      <div ref={sectionRef} className="fade-up max-w-[85rem] mx-auto px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-20">
          
          {/* LEFT: Typography & Info (Editorial Style) */}
          <div className="w-full lg:w-5/12 flex flex-col justify-center text-center lg:text-left pt-10 lg:pt-0">
            <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-2 lg:mb-12">
              Merkezimizden Kareler
            </p>
            
            {/* Mobile Title (Static) */}
            <h2 className="lg:hidden font-heading text-4xl sm:text-5xl font-bold text-charcoal mb-4">
              Vitrinimiz
            </h2>
            <p className="lg:hidden text-charcoal/60 text-base mb-8 max-w-sm mx-auto">
              Sola veya sağa kaydırarak merkezimizi keşfedin.
            </p>
            
            {/* The title of the CURRENT slide with a fade transition (DESKTOP ONLY) */}
            <div className="hidden lg:block relative h-40 sm:h-48 lg:h-64">
              {slides.map((slide, i) => (
                <div 
                  key={i} 
                  className={`absolute inset-0 transition-all duration-700 ease-out ${
                    i === current ? 'opacity-100 translate-y-0 z-10' : 'opacity-0 translate-y-8 pointer-events-none z-0'
                  }`}
                >
                  <div className="text-pink-50 font-heading text-8xl lg:text-[10rem] leading-none font-bold absolute -top-12 lg:-top-20 -left-4 lg:-left-12 select-none pointer-events-none z-0">
                    0{i+1}
                  </div>
                  <h2 className="relative z-10 font-heading text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-charcoal leading-[1.1] drop-shadow-sm">
                    {slide.title}
                  </h2>
                  <p className="relative z-10 mt-6 lg:mt-8 text-charcoal/60 text-lg lg:text-xl max-w-md mx-auto lg:mx-0 font-light leading-relaxed">
                    {slide.subtitle}
                  </p>
                </div>
              ))}
            </div>
            
            {/* Minimalist Controls below text on Desktop */}
            <div className="hidden lg:flex items-center gap-6 mt-12">
              <button onClick={prev} className="group flex items-center justify-center w-14 h-14 rounded-full border border-pink-200 hover:bg-pink-500 hover:border-pink-500 transition-all duration-300 shadow-sm hover:shadow-pink-200">
                <svg className="w-5 h-5 text-pink-500 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
              </button>
              <button onClick={next} className="group flex items-center justify-center w-14 h-14 rounded-full border border-pink-200 hover:bg-pink-500 hover:border-pink-500 transition-all duration-300 shadow-sm hover:shadow-pink-200">
                <svg className="w-5 h-5 text-pink-500 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
              </button>
              <div className="flex items-center gap-4 ml-6">
                {slides.map((_, i) => (
                  <button key={i} onClick={() => goTo(i)} className={`rounded-full transition-all duration-500 ${i === current ? 'w-12 h-1.5 bg-pink-500' : 'w-2 h-1.5 bg-pink-200 hover:bg-pink-300'}`} aria-label={`Slide ${i + 1}`} />
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: Photo Frame */}
          <div className="w-full lg:w-7/12 relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[280px] sm:max-w-md lg:max-w-lg pb-12 lg:pb-0">
              
              {/* Carousel wrapper */}
              <div
                className="w-full"
                onMouseEnter={() => setPaused(true)}
                onMouseLeave={() => setPaused(false)}
                onTouchStart={onTouchStart}
                onTouchEnd={onTouchEnd}
              >
                {/* ---------------- DESKTOP POLAROID CARD STACK ---------------- */}
                <div className="hidden lg:block relative aspect-[2/3] w-full z-10">
                  {slides.map((slide, i) => {
                    const diff = (i - current + slides.length) % slides.length;
                    
                    // Fiziksel fotoğraf yığını (Stack) animasyon sınıfları
                    let stackClasses = "absolute inset-0 flex flex-col overflow-hidden bg-white border border-charcoal/10 rounded-[2rem] shadow-2xl shadow-charcoal/10 transition-all duration-700 ease-[cubic-bezier(0.23,1,0.32,1)] p-4 pb-5 origin-bottom ";
                    
                    if (diff === 0) {
                      stackClasses += "z-30 opacity-100 scale-100 translate-y-0 translate-x-0 rotate-0";
                    } else if (diff === 1) {
                      stackClasses += "z-20 opacity-90 scale-[0.93] translate-y-4 translate-x-6 rotate-3";
                    } else if (diff === 2) {
                      stackClasses += "z-10 opacity-60 scale-[0.86] translate-y-8 translate-x-12 rotate-6";
                    } else {
                      stackClasses += "z-0 opacity-0 scale-[0.80] translate-y-12 translate-x-16 rotate-12 pointer-events-none";
                    }

                    return (
                      <div key={i} className={stackClasses}>
                        {/* İç Fotoğraf */}
                        <div className="relative w-full flex-1 overflow-hidden rounded-[1rem] bg-charcoal">
                          <img src={slide.src} alt={slide.alt} className="w-full h-full object-cover relative z-[1]" loading={i === 0 ? 'eager' : 'lazy'} />
                        </div>
                        {/* Progress Bar (Sadece en öndeki kartta aktif görünmesi için) */}
                        <div className={`w-full bg-pink-50 h-[4px] rounded-full overflow-hidden mt-5 shadow-inner transition-opacity duration-300 ${diff === 0 ? 'opacity-100' : 'opacity-0'}`}>
                          {diff === 0 && (
                            <div key={progressKey} className={`showcase-progress h-full bg-pink-400 ${paused ? 'paused' : ''}`} />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* ---------------- MOBILE CARD STACK ---------------- */}
                <div className="block lg:hidden relative aspect-[2/3] w-full z-10">
                  {slides.map((slide, i) => {
                    const diff = (i - current + slides.length) % slides.length;
                    let stackClasses = "absolute inset-0 rounded-[2rem] overflow-hidden transition-all duration-500 ease-out shadow-2xl bg-charcoal ";
                    if (diff === 0) {
                      stackClasses += "z-30 opacity-100 scale-100 translate-y-0";
                    } else if (diff === 1) {
                      stackClasses += "z-20 opacity-90 scale-[0.92] translate-y-6";
                    } else if (diff === 2) {
                      stackClasses += "z-10 opacity-50 scale-[0.84] translate-y-12";
                    } else {
                      stackClasses += "z-0 opacity-0 scale-[0.75] translate-y-20 pointer-events-none";
                    }

                    return (
                      <div key={i} className={stackClasses}>
                        <img src={slide.src} alt={slide.alt} className="w-full h-full object-cover" loading={i === 0 ? 'eager' : 'lazy'} />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        <div className="absolute bottom-0 left-0 right-0 p-6 text-white text-center">
                          <h3 className="font-heading text-2xl font-bold mb-2 drop-shadow-md">{slide.title}</h3>
                          <p className="text-white/80 text-sm font-light drop-shadow-md">{slide.subtitle}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>

              {/* Mobile Controls (hidden on lg) */}
              <div className="flex lg:hidden items-center justify-center gap-6 mt-6 z-30 relative">
                <button onClick={prev} className="w-12 h-12 rounded-full border border-pink-200 bg-white shadow-md flex items-center justify-center text-pink-500 active:scale-90 transition-transform">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
                </button>
                <div className="flex items-center gap-2.5">
                  {slides.map((_, i) => (
                    <button key={i} onClick={() => goTo(i)} className={`rounded-full transition-all duration-500 ${i === current ? 'w-10 h-2 bg-pink-500' : 'w-2 h-2 bg-pink-200'}`} />
                  ))}
                </div>
                <button onClick={next} className="w-12 h-12 rounded-full border border-pink-200 bg-white shadow-md flex items-center justify-center text-pink-500 active:scale-90 transition-transform">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>

      {/* Bottom decorative gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-pink-50/50 to-transparent pointer-events-none" />
    </section>
  )
}
