const sharp = require('sharp');
const path = require('path');

const SRC_DIR = path.join(__dirname, 'src', 'assets', 'estepinkfoto');
const OUT_DIR = path.join(__dirname, 'public', 'images');

const heroTask = {
  input: path.join(SRC_DIR, 'EOSR9794.JPG'),
  outputWebp: path.join(OUT_DIR, 'hero-bg.webp'),
  outputJpg: path.join(OUT_DIR, 'hero-bg.jpg'),
  width: 1920,
};

async function restoreHero() {
  console.log('Restoring original uncropped hero image...');
  
  // Create uncropped WebP
  await sharp(heroTask.input)
    .resize({ width: heroTask.width, withoutEnlargement: true })
    .webp({ quality: 85 })
    .toFile(heroTask.outputWebp);
    
  // Create uncropped JPG fallback
  await sharp(heroTask.input)
    .resize({ width: heroTask.width, withoutEnlargement: true })
    .jpeg({ quality: 80, mozjpeg: true })
    .toFile(heroTask.outputJpg);

  console.log('Done! Hero is now the full uncropped portrait photo.');
}

restoreHero().catch(console.error);
