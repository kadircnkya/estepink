import { useState, useEffect, useCallback, useRef } from 'react'
import { useReveal } from '../hooks/useAnimations'

const testimonials = [
  {
    name: 'Ayşe K.',
    service: 'Lazer Epilasyon',
    rating: 5,
    text: 'EstePink\'te aldığım lazer epilasyon hizmeti gerçekten mükemmeldi. Acısız ve son derece etkili. Personel çok ilgili ve profesyonel.',
  },
  {
    name: 'Merve T.',
    service: 'Cilt Bakımı',
    rating: 5,
    text: 'Hydrafacial sonrası cildim inanılmaz parladı. Düzenli geliyorum ve her seferinde çok memnun kalıyorum. Herkese tavsiye ederim.',
  },
  {
    name: 'Elif S.',
    service: 'Medikal Estetik',
    rating: 5,
    text: 'Dudak dolgusu yaptırdım, sonuç tam istediğim gibi doğal oldu. Doktora ve ekibe teşekkürler. Kesinlikle tavsiye ederim.',
  },
  {
    name: 'Zeynep D.',
    service: 'Bölgesel İncelme',
    rating: 4,
    text: 'Seanslarım sonrası gözle görülür fark oluştu. Ortam ve uzmanlar çok profesyonel. Kendimi güvende hissettim.',
  },
]

function StarRating({ rating }) {
  return (
    <div className="star-rating justify-center mb-6">
      {[1, 2, 3, 4, 5].map((star) => (
        <svg
          key={star}
          className={`w-5 h-5 star ${star <= rating ? '' : 'opacity-25'}`}
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  )
}

export default function Testimonials() {
  const ref = useReveal()
  const [current, setCurrent] = useState(0)
  const [animState, setAnimState] = useState('fade-active')
  const touchStart = useRef(null)

  const goTo = useCallback((index) => {
    // Fade out
    setAnimState('fade-exit')
    setTimeout(() => {
      setCurrent(index)
      setAnimState('fade-enter')
      // Trigger reflow then fade in
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setAnimState('fade-active')
        })
      })
    }, 400)
  }, [])

  const next = useCallback(() => {
    goTo((current + 1) % testimonials.length)
  }, [current, goTo])

  const prev = useCallback(() => {
    goTo((current - 1 + testimonials.length) % testimonials.length)
  }, [current, goTo])

  useEffect(() => {
    const t = setInterval(() => {
      goTo(((c) => (c + 1) % testimonials.length)(current))
    }, 6000)
    return () => clearInterval(t)
  }, [current, goTo])

  // Touch/swipe support
  const onTouchStart = (e) => {
    touchStart.current = e.touches[0].clientX
  }

  const onTouchEnd = (e) => {
    if (touchStart.current === null) return
    const diff = touchStart.current - e.changedTouches[0].clientX
    if (Math.abs(diff) > 50) {
      diff > 0 ? next() : prev()
    }
    touchStart.current = null
  }

  const t = testimonials[current]

  return (
    <section id="yorumlar" className="py-20 lg:py-32 bg-white">
      <div ref={ref} className="fade-up max-w-4xl mx-auto px-6 lg:px-10 text-center">
        <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-4">
          Müşteri Yorumları
        </p>
        <h2 className="font-heading text-4xl lg:text-5xl font-bold text-charcoal mb-16">
          Ne Diyorlar?
        </h2>

        {/* Yorum */}
        <div
          className="min-h-[260px] flex flex-col items-center justify-center"
          onTouchStart={onTouchStart}
          onTouchEnd={onTouchEnd}
        >
          <div className={`testimonial-content ${animState}`}>
            {/* Quote Icon */}
            <div className="text-pink-300 mb-6">
              <svg className="w-12 h-12 mx-auto" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10H14.017zM0 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151C7.546 6.068 5.983 8.789 5.983 11H10v10H0z" />
              </svg>
            </div>

            {/* Star Rating */}
            <StarRating rating={t.rating} />

            {/* Text */}
            <p className="text-charcoal text-xl lg:text-2xl leading-relaxed font-light italic mb-10 max-w-2xl">
              &ldquo;{t.text}&rdquo;
            </p>

            {/* Author */}
            <div>
              <p className="text-charcoal font-semibold">{t.name}</p>
              <p className="text-pink-500 text-sm">{t.service}</p>
            </div>
          </div>
        </div>

        {/* Dots + Nav */}
        <div className="flex justify-center items-center gap-4 mt-12">
          <button
            onClick={prev}
            className="w-9 h-9 rounded-full border border-pink-200 flex items-center justify-center text-pink-400 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-all duration-300"
            aria-label="Önceki yorum"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex gap-2.5">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                className={`h-2 rounded-full transition-all duration-500 ${
                  i === current ? 'w-8 bg-pink-500' : 'w-2 bg-pink-200 hover:bg-pink-300'
                }`}
                aria-label={`Yorum ${i + 1}`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="w-9 h-9 rounded-full border border-pink-200 flex items-center justify-center text-pink-400 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-all duration-300"
            aria-label="Sonraki yorum"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </section>
  )
}
