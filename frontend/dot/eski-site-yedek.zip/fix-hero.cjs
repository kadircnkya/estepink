const sharp = require('sharp');
const path = require('path');

const SRC = path.join(__dirname, 'src', 'assets', 'estepinkfoto', 'EOSR9794.JPG');
const OUT_DIR = path.join(__dirname, 'public', 'images');

async function createHeroImage() {
  const meta = await sharp(SRC).metadata();
  console.log(`Original: ${meta.width}x${meta.height}`);

  // Strategy: Use the full width but take as much height as possible
  // while still being landscape. Use 16:10 ratio to show MORE of the image
  const targetWidth = meta.width;
  const targetHeight = Math.round(meta.width * 10 / 16); // 16:10 — taller than 16:9
  
  // Start from 15% from top — captures logo AND interior
  const top = Math.round(meta.height * 0.12);
  const actualHeight = Math.min(targetHeight, meta.height - top);
  
  console.log(`Cropping: ${targetWidth}x${actualHeight}, from y=${top} (ratio: ${(targetWidth/actualHeight).toFixed(2)})`);

  // Hero WebP
  const info = await sharp(SRC)
    .extract({ left: 0, top, width: targetWidth, height: actualHeight })
    .resize({ width: 1920, withoutEnlargement: true })
    .webp({ quality: 88 })
    .toFile(path.join(OUT_DIR, 'hero-bg.webp'));

  console.log(`WebP: ${info.width}x${info.height} — ${(info.size/1024).toFixed(0)}KB`);

  // Hero JPG fallback  
  await sharp(SRC)
    .extract({ left: 0, top, width: targetWidth, height: actualHeight })
    .resize({ width: 1920, withoutEnlargement: true })
    .jpeg({ quality: 82, mozjpeg: true })
    .toFile(path.join(OUT_DIR, 'hero-bg.jpg'));

  console.log('Done!');
}

createHeroImage().catch(console.error);
