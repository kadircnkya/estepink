const sharp = require('sharp');
const path = require('path');

const SRC = path.join(__dirname, 'src', 'assets', 'estepinkfoto', 'heroUpdate.png');
const OUT_DIR = path.join(__dirname, 'public', 'images');

async function processHeroUpdate() {
  try {
    const meta = await sharp(SRC).metadata();
    console.log(`Original heroUpdate: ${meta.width}x${meta.height}`);

    // Create optimized webp
    await sharp(SRC)
      .resize({ width: 1920, withoutEnlargement: true })
      .webp({ quality: 88 })
      .toFile(path.join(OUT_DIR, 'heroupdate-bg.webp'));

    // Create optimized jpg
    await sharp(SRC)
      .resize({ width: 1920, withoutEnlargement: true })
      .jpeg({ quality: 82, mozjpeg: true })
      .toFile(path.join(OUT_DIR, 'heroupdate-bg.jpg'));

    console.log('Optimized heroUpdate created successfully!');
  } catch (err) {
    console.error('Error:', err.message);
  }
}

processHeroUpdate();
