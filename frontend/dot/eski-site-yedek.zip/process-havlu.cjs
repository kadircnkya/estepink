const sharp = require('sharp');
const path = require('path');

const SRC = path.join(__dirname, 'src', 'assets', 'estepinkfoto', 'havlu.jpg');
const OUT_DIR = path.join(__dirname, 'public', 'images');

async function processHavluImage() {
  try {
    const meta = await sharp(SRC).metadata();
    console.log(`Original havlu.jpg: ${meta.width}x${meta.height}`);

    // Create optimized webp
    await sharp(SRC)
      .resize({ width: 1080, withoutEnlargement: true })
      .webp({ quality: 85 })
      .toFile(path.join(OUT_DIR, 'showcase-havlu.webp'));

    // Create optimized jpg
    await sharp(SRC)
      .resize({ width: 1080, withoutEnlargement: true })
      .jpeg({ quality: 80, mozjpeg: true })
      .toFile(path.join(OUT_DIR, 'showcase-havlu.jpg'));

    console.log('Optimized havlu image created successfully!');
  } catch (err) {
    console.error('Error:', err.message);
  }
}

processHavluImage();
