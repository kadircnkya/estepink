import { useCountUp } from '../hooks/useAnimations'

const stats = [
  { value: 10000, label: 'Mutlu Müşteri', suffix: '+' },
  { value: 10, label: 'Yıl Deneyim', suffix: '+' },
  { value: 15, label: 'Uzman Personel', suffix: '' },
  { value: 25, label: 'Hizmet Çeşidi', suffix: '+' },
]

function Stat({ value, label, suffix }) {
  const [ref, count] = useCountUp(value, 2000)

  return (
    <div ref={ref} className="text-center">
      <div className="font-heading text-4xl lg:text-5xl font-bold text-pink-600 mb-2">
        {count.toLocaleString('tr-TR')}{suffix}
      </div>
      <div className="text-charcoal/60 text-sm font-medium tracking-wide">{label}</div>
    </div>
  )
}

export default function Stats() {
  return (
    <section className="py-16 lg:py-20 bg-pink-50 border-y border-pink-100">
      <div className="max-w-5xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, i) => (
            <Stat key={i} {...stat} />
          ))}
        </div>
      </div>
    </section>
  )
}
