const sharp = require('sharp');
const path = require('path');

const SRC = path.join(__dirname, 'src', 'assets', 'estepinkfoto', 'HomeImage.JPG');
const OUT_DIR = path.join(__dirname, 'public', 'images');

async function processHomeImage() {
  try {
    const meta = await sharp(SRC).metadata();
    console.log(`Original HomeImage: ${meta.width}x${meta.height}`);

    // Create optimized webp
    await sharp(SRC)
      .resize({ width: 1920, withoutEnlargement: true })
      .webp({ quality: 85 })
      .toFile(path.join(OUT_DIR, 'homeimage-bg.webp'));

    // Create optimized jpg
    await sharp(SRC)
      .resize({ width: 1920, withoutEnlargement: true })
      .jpeg({ quality: 80, mozjpeg: true })
      .toFile(path.join(OUT_DIR, 'homeimage-bg.jpg'));

    console.log('Optimized HomeImage created successfully!');
  } catch (err) {
    console.error('Error:', err.message);
  }
}

processHomeImage();
