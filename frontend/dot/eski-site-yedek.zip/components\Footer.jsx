import { useState, useEffect } from 'react'

export default function Footer() {
  const year = new Date().getFullYear()
  const go = (id) => document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' })
  const [showTop, setShowTop] = useState(false)

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })

  return (
    <footer className="bg-charcoal text-white relative">
      {/* Gradient top line */}
      <div className="footer-gradient-top" />

      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <img
              src="/images/logo-transparent.png"
              alt="EstePink"
              className="h-14 w-auto object-contain brightness-0 invert"
            />
            <p className="text-white/40 text-sm leading-relaxed mt-4 max-w-xs">
              Profesyonel estetik ve güzellik hizmetleri ile güzelliğinize değer katıyoruz.
            </p>
            {/* Sosyal Medya */}
            <div className="flex gap-3 mt-6">
              {/* Instagram */}
              <a href="#" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="Instagram">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                </svg>
              </a>
              {/* Facebook */}
              <a href="#" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="Facebook">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
              {/* TikTok */}
              <a href="#" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:bg-pink-500 hover:text-white transition-all duration-300 hover:scale-110" aria-label="TikTok">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Linkler */}
          <div>
            <h4 className="text-white/80 text-xs font-semibold tracking-[3px] uppercase mb-6">Sayfalar</h4>
            <ul className="space-y-3">
              {[
                { id: '#anasayfa', label: 'Ana Sayfa' },
                { id: '#hakkimizda', label: 'Hakkımızda' },
                { id: '#hizmetler', label: 'Hizmetler' },
                { id: '#yorumlar', label: 'Yorumlar' },
                { id: '#iletisim', label: 'İletişim' },
              ].map((link) => (
                <li key={link.id}>
                  <button onClick={() => go(link.id)} className="text-white/40 hover:text-pink-400 hover:translate-x-1 text-sm transition-all duration-300 inline-flex items-center gap-2 group">
                    <span className="w-0 group-hover:w-2 h-[1px] bg-pink-400 transition-all duration-300" />
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Hizmetler */}
          <div>
            <h4 className="text-white/80 text-xs font-semibold tracking-[3px] uppercase mb-6">Hizmetler</h4>
            <ul className="space-y-3">
              {['Lazer Epilasyon', 'Cilt Bakımı', 'Medikal Estetik', 'Hydrafacial', 'Bölgesel İncelme', 'İpek Kirpik'].map((s) => (
                <li key={s}>
                  <button onClick={() => go('#hizmetler')} className="text-white/40 hover:text-pink-400 hover:translate-x-1 text-sm transition-all duration-300 inline-flex items-center gap-2 group">
                    <span className="w-0 group-hover:w-2 h-[1px] bg-pink-400 transition-all duration-300" />
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* İletişim */}
          <div>
            <h4 className="text-white/80 text-xs font-semibold tracking-[3px] uppercase mb-6">İletişim</h4>
            <div className="space-y-4 text-white/40 text-sm">
              <div className="flex gap-3 items-start">
                <svg className="w-4 h-4 text-pink-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <p>Örnek Mah. Güzellik Cad.<br />No: 42, İstanbul</p>
              </div>
              <div className="flex gap-3 items-center">
                <svg className="w-4 h-4 text-pink-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <p>+90 (212) 555 00 00</p>
              </div>
              <div className="flex gap-3 items-center">
                <svg className="w-4 h-4 text-pink-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <p>info@estepink.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Alt çizgi */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-5 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-white/30 text-xs">
            © {year} EstePink. Tüm hakları saklıdır.
          </p>
          <div className="flex gap-4">
            <a href="#" className="text-white/30 hover:text-pink-400 text-xs transition-colors">Gizlilik</a>
            <a href="#" className="text-white/30 hover:text-pink-400 text-xs transition-colors">Şartlar</a>
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <button
        onClick={scrollToTop}
        className={`back-to-top fixed bottom-24 right-6 z-30 w-11 h-11 rounded-full bg-pink-500 text-white flex items-center justify-center shadow-lg shadow-pink-500/25 hover:bg-pink-600 hover:shadow-pink-500/40 ${showTop ? 'visible' : ''}`}
        aria-label="Yukarı çık"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
        </svg>
      </button>
    </footer>
  )
}
