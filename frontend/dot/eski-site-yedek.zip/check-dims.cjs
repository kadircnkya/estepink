const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const SRC_DIR = path.join(__dirname, 'src', 'assets', 'estepinkfoto');

const files = [
  'EOSR9801.JPG',
  'EOSR9821.JPG',
  'EOSR9847.JPG',
  'EOSR9797.JPG',
  'EOSR9838.JPG',
  'havlu.jpg'
];

async function checkDims() {
  for (const f of files) {
    const meta = await sharp(path.join(SRC_DIR, f)).metadata();
    console.log(`${f}: ${meta.width}x${meta.height} (ratio: ${(meta.width/meta.height).toFixed(2)})`);
  }
}

checkDims();
