import { useReveal } from '../hooks/useAnimations'

export default function About() {
  const ref = useReveal()

  return (
    <section id="hakkimizda" className="py-20 lg:py-32 bg-white">
      <div ref={ref} className="fade-up max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-20 items-center">
          {/* Sol — Dekoratif Accent */}
          <div className="relative flex items-center justify-center">
            <div className="relative">
              {/* Ana dekoratif kutu */}
              <div className="w-64 h-80 sm:w-80 sm:h-96 rounded-2xl bg-gradient-to-br from-pink-100 to-pink-50 flex items-center justify-center">
                <div className="text-center px-8">
                  <div className="w-16 h-16 rounded-full bg-pink-500/10 flex items-center justify-center mx-auto mb-6">
                    <svg className="w-8 h-8 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </div>
                  <p className="font-heading text-5xl sm:text-6xl font-bold text-pink-500 mb-2">10+</p>
                  <p className="text-charcoal/60 text-sm font-medium tracking-wide uppercase">Yıllık Deneyim</p>
                </div>
              </div>
              {/* Küçük accent kare */}
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-pink-200/50 rounded-xl -z-10" />
              <div className="absolute -top-4 -left-4 w-16 h-16 bg-pink-100/60 rounded-lg -z-10" />
            </div>
          </div>

          {/* Sağ — Metin */}
          <div className="lg:pl-4">
            <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-4">
              Hakkımızda
            </p>

            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-charcoal leading-tight mb-6">
              Güzelliğe adanmış
              <br />
              <span className="text-pink-500 italic">profesyonel ekip</span>
            </h2>

            <p className="text-text-secondary text-lg leading-relaxed mb-6">
              EstePink olarak, müşterilerimize en kaliteli estetik ve güzellik
              hizmetlerini sunuyoruz. Uzman kadromuz, kişiye özel çözümler üreterek
              doğal güzelliğinizi ortaya çıkarmayı hedefliyor.
            </p>

            <p className="text-text-secondary leading-relaxed mb-10">
              FDA onaylı son teknoloji cihazlarımız, steril ortamımız ve yılların
              birikimiyle, güvenli ve etkili sonuçlar sunuyoruz. Her müşterimiz
              bizim için özeldir.
            </p>

            {/* Özellik listesi — ikonlu */}
            <div className="grid grid-cols-2 gap-5">
              {[
                { label: 'FDA Onaylı Cihazlar', icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
                { label: 'Uzman Kadro', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z' },
                { label: 'Steril Ortam', icon: 'M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z' },
                { label: 'Kişiye Özel Bakım', icon: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z' },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3 group">
                  <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center group-hover:bg-pink-100 transition-colors duration-300 flex-shrink-0">
                    <svg className="w-4 h-4 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={item.icon} />
                    </svg>
                  </div>
                  <span className="text-charcoal text-sm font-medium">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
