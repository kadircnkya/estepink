import { useState, useEffect } from 'react'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
  }, [mobileOpen])

  const links = [
    { href: '#hakkimizda', label: 'Hakkımızda' },
    { href: '#hizmetler', label: 'Hizmetler' },
    { href: '#yorumlar', label: 'Yorumlar' },
    { href: '#iletisim', label: 'İletişim' },
  ]

  const go = (e, href) => {
    e.preventDefault()
    setMobileOpen(false)
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm py-2' : 'bg-transparent py-3'
    }`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between">
        {/* Logo — transparent PNG */}
        <a
          href="#"
          className="relative z-50 flex-shrink-0"
          onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
        >
          <img
            src="/images/logo-transparent.png"
            alt="EstePink"
            className={`h-12 sm:h-14 lg:h-16 w-auto object-contain transition-all duration-500 ${
              scrolled || mobileOpen
                ? ''
                : 'brightness-0 invert drop-shadow-[0_1px_3px_rgba(0,0,0,0.3)]'
            }`}
          />
        </a>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-10">
          {links.map(({ href, label }) => (
            <a
              key={href}
              href={href}
              onClick={(e) => go(e, href)}
              className={`text-[13px] font-medium tracking-widest uppercase transition-colors duration-300 hover:text-pink-500 ${
                scrolled ? 'text-charcoal/60' : 'text-white/70'
              }`}
            >
              {label}
            </a>
          ))}
          <a
            href="#iletisim"
            onClick={(e) => go(e, '#iletisim')}
            className="ml-2 px-6 py-2.5 bg-pink-500 text-white text-[13px] font-semibold tracking-wider uppercase rounded-full hover:bg-pink-600 transition-colors duration-300"
          >
            Randevu
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden relative z-50 w-8 h-8 flex flex-col justify-center items-center gap-1.5"
          aria-label="Menü"
        >
          <span className={`block w-6 h-[1.5px] transition-all duration-300 ${
            mobileOpen ? 'rotate-45 translate-y-[3.5px] bg-charcoal' : scrolled ? 'bg-charcoal' : 'bg-white'
          }`} />
          <span className={`block w-6 h-[1.5px] transition-all duration-300 ${
            mobileOpen ? '-rotate-45 -translate-y-[3.5px] bg-charcoal' : scrolled ? 'bg-charcoal' : 'bg-white'
          }`} />
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden fixed inset-0 bg-white z-40 flex flex-col items-center justify-center transition-all duration-500 ${
        mobileOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
      }`}>
        <div className="flex flex-col items-center gap-8">
          {/* Mobil menüde büyük renkli logo */}
          <img
            src="/images/logo-transparent.png"
            alt="EstePink"
            className="h-20 w-auto object-contain mb-4"
          />
          {links.map(({ href, label }) => (
            <a
              key={href}
              href={href}
              onClick={(e) => go(e, href)}
              className="text-charcoal text-2xl font-heading font-medium hover:text-pink-500 transition-colors"
            >
              {label}
            </a>
          ))}
          <a
            href="#iletisim"
            onClick={(e) => go(e, '#iletisim')}
            className="mt-4 px-10 py-3 bg-pink-500 text-white font-semibold rounded-full"
          >
            Randevu Al
          </a>
        </div>
      </div>
    </nav>
  )
}
