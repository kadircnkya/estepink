import { useState, useRef, useEffect } from 'react'
import { useReveal } from '../hooks/useAnimations'
import { Play, X, Volume2, VolumeX } from 'lucide-react'

export default function VideoShowcase() {
  const sectionRef = useReveal()
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)
  const videoRef = useRef(null)
  const lightboxRef = useRef(null)

  // Close lightbox on Escape
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape' && isPlaying) {
        closeLightbox()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [isPlaying])

  const openLightbox = () => {
    setIsPlaying(true)
    document.body.style.overflow = 'hidden'
  }

  const closeLightbox = () => {
    setIsPlaying(false)
    setIsMuted(true)
    document.body.style.overflow = ''
    if (videoRef.current) {
      videoRef.current.pause()
      videoRef.current.currentTime = 0
    }
  }

  return (
    <>
      <section className="relative overflow-hidden">
        {/* Top gradient — Hero'dan gelen yumuşak geçiş */}
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-charcoal to-transparent z-10 pointer-events-none" />

        <div ref={sectionRef} className="fade-up">
          {/* Cinematic Video Banner */}
          <div className="relative h-[50vh] lg:h-[60vh] overflow-hidden group cursor-pointer" onClick={openLightbox}>
            {/* Background */}
            <div className="absolute inset-0 bg-charcoal">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-900/90 via-charcoal to-charcoal" />
              {/* Animated gradient orbs */}
              <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-[120px] animate-pulse" />
              <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-pink-400/15 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />
            </div>

            {/* Overlay */}
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-500" />

            {/* Content */}
            <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-6">
              {/* Play Button */}
              <button 
                className="video-play-btn w-20 h-20 lg:w-24 lg:h-24 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center mb-8 group-hover:bg-pink-500/80 group-hover:border-pink-400 group-hover:scale-110 transition-all duration-500"
                aria-label="Tanıtım Videosunu Oynat"
              >
                <Play className="w-8 h-8 lg:w-10 lg:h-10 text-white ml-1" fill="white" />
              </button>

              {/* Text */}
              <p className="text-pink-300/80 text-[13px] font-semibold tracking-[6px] uppercase mb-4">
                Tanıtım Videosu
              </p>
              <h2 className="font-heading text-3xl sm:text-4xl lg:text-6xl font-bold text-white leading-tight mb-4">
                EstePink'i <span className="text-pink-300 italic">Keşfedin</span>
              </h2>
              <p className="text-white/50 text-base lg:text-lg max-w-lg font-light">
                Merkezimizi yakından tanıyın, uzman kadromuzu ve hizmetlerimizi keşfedin
              </p>

              {/* Decorative line */}
              <div className="mt-8 w-16 h-[1px] bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
            </div>
          </div>
        </div>

        {/* Bottom gradient — About ile yumuşak geçiş */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-10 pointer-events-none" />
      </section>

      {/* Video Lightbox */}
      {isPlaying && (
        <div 
          ref={lightboxRef}
          className="fixed inset-0 z-[9999] flex items-center justify-center"
          onClick={(e) => { if (e.target === lightboxRef.current) closeLightbox() }}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/95 lightbox-overlay" />

          {/* Video Container */}
          <div className="relative z-10 w-full max-w-5xl mx-4 lightbox-image">
            {/* Close Button */}
            <button
              onClick={closeLightbox}
              className="absolute -top-12 right-0 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors duration-300"
              aria-label="Kapat"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Video Player Area */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-charcoal border border-white/10">
              {/* Placeholder */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
                <div className="w-20 h-20 rounded-full bg-pink-500/20 flex items-center justify-center mb-6 animate-pulse">
                  <Play className="w-10 h-10 text-pink-400 ml-1" />
                </div>
                <p className="text-white/60 text-lg font-light mb-2">
                  Video alanı hazır
                </p>
                <p className="text-white/30 text-sm max-w-md">
                  Tanıtım videonuzu buraya ekleyeceğiz. MP4 formatında videoyu paylaştığınızda entegre edilecek.
                </p>
              </div>

              {/* Mute toggle */}
              <button
                onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted) }}
                className="absolute bottom-4 right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors duration-300 z-20"
                aria-label={isMuted ? 'Sesi Aç' : 'Sesi Kapat'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
