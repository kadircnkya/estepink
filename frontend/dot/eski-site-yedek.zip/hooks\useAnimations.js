import { useEffect, useRef, useState, useCallback } from 'react'

export function useReveal() {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add('visible')
          observer.unobserve(el)
        }
      },
      { threshold: 0.15 }
    )

    observer.observe(el)
    return () => observer.unobserve(el)
  }, [])

  return ref
}

export function useCountUp(end, duration = 2000) {
  const [count, setCount] = useState(0)
  const [started, setStarted] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true)
          observer.unobserve(el)
        }
      },
      { threshold: 0.3 }
    )

    observer.observe(el)
    return () => observer.unobserve(el)
  }, [])

  useEffect(() => {
    if (!started) return
    let start = null
    let prevValue = 0
    const step = (ts) => {
      if (!start) start = ts
      const progress = Math.min((ts - start) / duration, 1)
      // Ease-out cubic for smoother feel
      const eased = 1 - Math.pow(1 - progress, 3)
      const newValue = Math.floor(eased * end)
      // Only update state when value actually changes — avoids unnecessary re-renders
      if (newValue !== prevValue) {
        prevValue = newValue
        setCount(newValue)
      }
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [started, end, duration])

  return [ref, count]
}

/**
 * Throttle utility — limits callback execution to once per `ms` milliseconds.
 * Uses requestAnimationFrame-aligned timing for buttery smooth scroll handlers.
 */
export function useThrottle(callback, ms = 100) {
  const lastCall = useRef(0)
  const pendingFrame = useRef(null)

  return useCallback((...args) => {
    const now = Date.now()
    if (now - lastCall.current >= ms) {
      lastCall.current = now
      callback(...args)
    } else if (!pendingFrame.current) {
      pendingFrame.current = requestAnimationFrame(() => {
        lastCall.current = Date.now()
        pendingFrame.current = null
        callback(...args)
      })
    }
  }, [callback, ms])
}
