import { useRef, useState, useEffect, useCallback } from 'react'
import { useReveal, useThrottle } from '../hooks/useAnimations'

const photos = [
  { src: '/images/hero-bg.jpg', alt: 'EstePink Salon' },
  { src: '/images/service-laser.jpg', alt: 'Lazer Epilasyon' },
  { src: '/images/service-skincare.jpg', alt: 'Cilt Bakımı' },
  { src: '/images/service-medical.jpg', alt: 'Medikal Estetik' },
  { src: '/images/hero-bg.jpg', alt: 'Merkezimiz' },
  { src: '/images/service-laser.jpg', alt: 'Uygulama' },
  { src: '/images/service-skincare.jpg', alt: 'Profesyonel Bakım' },
  { src: '/images/service-medical.jpg', alt: 'Uzman Kadro' },
]

export default function Gallery() {
  const ref = useReveal()
  const scrollRef = useRef(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(true)
  const [lightboxIndex, setLightboxIndex] = useState(null)

  const checkScroll = useCallback(() => {
    const el = scrollRef.current
    if (!el) return
    setCanScrollLeft(el.scrollLeft > 10)
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 10)
  }, [])

  // Throttled scroll handler — prevents jank during gallery scroll
  const throttledCheckScroll = useThrottle(checkScroll, 100)

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    el.addEventListener('scroll', throttledCheckScroll, { passive: true })
    checkScroll()
    return () => el.removeEventListener('scroll', throttledCheckScroll)
  }, [throttledCheckScroll, checkScroll])

  const scroll = (dir) => {
    const el = scrollRef.current
    if (!el) return
    el.scrollBy({ left: dir * 400, behavior: 'smooth' })
  }

  // Lightbox navigation
  const lightboxNext = useCallback(() => {
    setLightboxIndex((i) => (i + 1) % photos.length)
  }, [])

  const lightboxPrev = useCallback(() => {
    setLightboxIndex((i) => (i - 1 + photos.length) % photos.length)
  }, [])

  const closeLightbox = useCallback(() => {
    setLightboxIndex(null)
  }, [])

  // Keyboard navigation for lightbox
  useEffect(() => {
    if (lightboxIndex === null) return
    const onKey = (e) => {
      if (e.key === 'Escape') closeLightbox()
      if (e.key === 'ArrowRight') lightboxNext()
      if (e.key === 'ArrowLeft') lightboxPrev()
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [lightboxIndex, closeLightbox, lightboxNext, lightboxPrev])

  return (
    <section id="galeri" className="py-20 lg:py-32 bg-white overflow-hidden">
      <div ref={ref} className="fade-up">
        {/* Başlık */}
        <div className="max-w-7xl mx-auto px-6 lg:px-10 mb-12 flex items-end justify-between">
          <div>
            <p className="text-pink-500 text-[13px] font-semibold tracking-[4px] uppercase mb-4">
              Galeri
            </p>
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-charcoal">
              Merkezimizden Kareler
            </h2>
          </div>

          {/* Scroll Butonları */}
          <div className="hidden sm:flex gap-3">
            <button
              onClick={() => scroll(-1)}
              disabled={!canScrollLeft}
              className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                canScrollLeft
                  ? 'border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white'
                  : 'border-gray-200 text-gray-300 cursor-default'
              }`}
              aria-label="Önceki"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              onClick={() => scroll(1)}
              disabled={!canScrollRight}
              className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                canScrollRight
                  ? 'border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white'
                  : 'border-gray-200 text-gray-300 cursor-default'
              }`}
              aria-label="Sonraki"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Kayan Fotoğraf Albümü */}
        <div
          ref={scrollRef}
          className="gallery-scroll pl-6 lg:pl-10"
        >
          {photos.map((photo, i) => (
            <div
              key={i}
              onClick={() => setLightboxIndex(i)}
              className="group cursor-pointer relative rounded-xl overflow-hidden"
              style={{ width: i === 0 ? '500px' : '340px', height: '420px' }}
            >
              <img
                src={photo.src}
                alt={photo.alt}
                className="img-cover group-hover:scale-105 transition-transform duration-700"
                loading="lazy"
              />
              {/* Hover overlay — sadece alt bilgi */}
              <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-black/50 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                <span className="text-white text-sm font-medium">{photo.alt}</span>
              </div>
            </div>
          ))}
          {/* Scroll padding */}
          <div className="w-6 lg:w-10 flex-shrink-0" />
        </div>

        {/* Mobil scroll hint */}
        <div className="sm:hidden flex justify-center mt-6">
          <div className="flex items-center gap-2 text-text-secondary text-xs">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <span>Kaydırarak görselleri keşfedin</span>
          </div>
        </div>
      </div>

      {/* Enhanced Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 lightbox-overlay"
          onClick={closeLightbox}
        >
          {/* Close button */}
          <button
            className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors z-20"
            onClick={closeLightbox}
            aria-label="Kapat"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* Previous button */}
          <button
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/25 transition-all duration-300 z-20"
            onClick={(e) => { e.stopPropagation(); lightboxPrev() }}
            aria-label="Önceki fotoğraf"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          {/* Image */}
          <div className="lightbox-image max-w-full max-h-[85vh]" onClick={(e) => e.stopPropagation()}>
            <img
              src={photos[lightboxIndex].src}
              alt={photos[lightboxIndex].alt}
              className="max-w-full max-h-[85vh] rounded-lg object-contain"
            />
            {/* Caption */}
            <div className="text-center mt-4">
              <p className="text-white/80 text-sm font-medium">{photos[lightboxIndex].alt}</p>
              <p className="text-white/40 text-xs mt-1">
                {lightboxIndex + 1} / {photos.length}
              </p>
            </div>
          </div>

          {/* Next button */}
          <button
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/25 transition-all duration-300 z-20"
            onClick={(e) => { e.stopPropagation(); lightboxNext() }}
            aria-label="Sonraki fotoğraf"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      )}
    </section>
  )
}
